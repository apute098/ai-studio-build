const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, downloadMediaMessage, jidNormalizedUser } = require('@whiskeysockets/baileys');
const TelegramBot = require('node-telegram-bot-api');
const pino = require('pino');
const qrcodeTerminal = require('qrcode-terminal');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');

// --- KONFIGURASI ---
const MONITOR_TOKEN = '8591251718:AAFnfnd0kgyE7OHZpqD_j8i_YMX2NAuzoH4'; 
const AI_TOKEN = '7102576389:AAG4_fLeRqUbDgL6L9zLlBG34XrELNJrrhE';      
const TELEGRAM_CHAT_ID = '-1003693049622';
const GEMINI_KEY = 'AIzaSyBkMxOOYKtd1F2yFT56QHamoj9WRQvUFFk';

// --- CONFIG WEB PANEL (Teledash) ---
const DASHBOARD_URL = 'https://ais-dev-crpq64x44ymcouxubqu6oh-862891872435.asia-southeast1.run.app/api/webhook/bridge'; 

const MODELS = ["gemini-2.0-flash", "gemini-2.5-flash", "gemini-1.5-flash"];

// --- DATABASE NAMA MANDIRI ---
let myContacts = {};
const CONTACTS_FILE = './kontak.json';
if (fs.existsSync(CONTACTS_FILE)) {
    try { myContacts = JSON.parse(fs.readFileSync(CONTACTS_FILE)); } catch (e) { myContacts = {}; }
}
function saveMyContacts() {
    fs.writeFileSync(CONTACTS_FILE, JSON.stringify(myContacts, null, 2));
}

let phoneStatus = { battery: "??", isCharging: false, isOnline: false, lastSeen: "-" };

const monitorBot = new TelegramBot(MONITOR_TOKEN, { polling: false }); 
const aiBot = new TelegramBot(AI_TOKEN, { polling: true });
aiBot.on('polling_error', () => {});

// --- FUNGSI BRIDGE KE WEB PANEL ---
async function pushToDashboard(text, username, jid = null, chatId = null) {
    try {
        await fetch(DASHBOARD_URL, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${MONITOR_TOKEN}` 
            },
            body: JSON.stringify({
                chatId: chatId || TELEGRAM_CHAT_ID,
                telegramId: jid,
                text: text,
                username: username,
                firstName: "WhatsApp",
                messageId: Date.now()
            })
        });
        console.log("🚀 Bridge: Data dikirim ke Teledash.");
    } catch (e) {
        console.log("❌ Bridge Gagal: " + e.message);
    }
}

// --- LOGIKA AI ---
async function callAI(prompt, imageBase64 = null) {
    const statusContext = `STATUS HP WAHYU: Baterai ${phoneStatus.battery}%, Cas: ${phoneStatus.isCharging ? "Ya" : "Tidak"}.`;
    for (let modelName of MODELS) {
        try {
            const parts = [{ text: `${statusContext}\nPertanyaan: ${prompt}` }];
            if (imageBase64) parts.push({ inline_data: { mime_type: "image/jpeg", data: imageBase64 } });
            const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${GEMINI_KEY}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ contents: [{ parts }] })
            });
            const data = await res.json();
            if (data.candidates && data.candidates[0].content) return { text: data.candidates[0].content.parts[0].text.trim(), model: modelName };
        } catch (e) {}
    }
    return { text: "AI limit Yu.", model: "None" };
}

aiBot.on('message', async (msg) => {
    if (msg.chat.id.toString() !== TELEGRAM_CHAT_ID || (msg.from && msg.from.is_bot)) return;
    const text = msg.text || msg.caption || "";
    const isPhoto = msg.photo && msg.photo.length > 0;
    const isReply = msg.reply_to_message;
    if (!text && !isPhoto && !(isReply && isReply.photo)) return;
    if (text.startsWith('/')) return;

    const sentMsg = await aiBot.sendMessage(TELEGRAM_CHAT_ID, `💬 _Berpikir..._`, { reply_to_message_id: msg.message_id });
    try {
        let imageBase64 = null;
        let targetPhoto = isPhoto ? msg.photo : (isReply && isReply.photo ? isReply.photo : null);
        if (targetPhoto) {
            const photoId = targetPhoto[targetPhoto.length - 1].file_id;
            const link = await aiBot.getFileLink(photoId);
            const res = await fetch(link);
            const buffer = await res.arrayBuffer();
            imageBase64 = Buffer.from(buffer).toString('base64');
        }
        const result = await callAI(text || "Jelaskan foto ini.", imageBase64);
        await aiBot.editMessageText(`🤖 ${result.text}\n\n_(via ${result.model})_`, { chat_id: TELEGRAM_CHAT_ID, message_id: sentMsg.message_id });
        
        // --- LOG AI KE DASHBOARD ---
        pushToDashboard(result.text, `AI (${result.model})`, "AI-Model", "AI-Chat");
    } catch (err) {
        aiBot.editMessageText(`🤖 Error: ${err.message}`, { chat_id: TELEGRAM_CHAT_ID, message_id: sentMsg.message_id });
    }
});

// --- LOGIKA WHATSAPP ---
async function startBot() {
    const { state, saveCreds } = await useMultiFileAuthState('auth_info');
    const { version } = await fetchLatestBaileysVersion();
    
    const sock = makeWASocket({ 
        version, auth: state, logger: pino({ level: 'error' }), 
        browser: ["Arch Linux", "Chrome", "1.0.0"],
        syncFullHistory: false, shouldSyncHistoryMessage: () => false
    });

    sock.ev.on('creds.update', saveCreds);

    const getStoredName = async (jid, pushName) => {
        if (!jid) return 'Unknown';
        const id = jidNormalizedUser(jid);
        if (myContacts[id]) return myContacts[id];
        if (id.endsWith('@g.us')) {
            try {
                const meta = await sock.groupMetadata(id);
                if (meta.subject) { myContacts[id] = meta.subject; saveMyContacts(); return meta.subject; }
            } catch (e) {}
            return `Grup (${id.split('@')[0]})`;
        }
        if (pushName) { myContacts[id] = pushName; saveMyContacts(); return pushName; }
        return id.split('@')[0];
    };

    sock.ev.on('connection.update', async (u) => {
        const { connection, lastDisconnect, qr, battery, charging } = u;
        if (battery !== undefined) { phoneStatus.battery = battery; phoneStatus.isCharging = !!charging; }
        
        if (qr) {
            qrcodeTerminal.generate(qr, { small: true });
            await QRCode.toFile(path.join(__dirname, 'qr.png'), qr).catch(() => {});
        }

        if (connection === 'open') {
            phoneStatus.isOnline = true;
            await monitorBot.sendMessage(TELEGRAM_CHAT_ID, '🟢 *regsi_bot ONLINE!*').catch(() => {});
            if (fs.existsSync(path.join(__dirname, 'qr.png'))) fs.unlinkSync(path.join(__dirname, 'qr.png'));
        } else if (connection === 'close') {
            phoneStatus.isOnline = false;
            const statusCode = (lastDisconnect?.error)?.output?.statusCode;
            const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
            if (shouldReconnect) setTimeout(startBot, 5000);
        }
    });

    sock.ev.on('messages.upsert', async ({ messages, type }) => {
        if (type !== 'notify') return;
        const m = messages[0];
        if (!m.message) return;

        const isMe = m.key.fromMe;
        const remoteJid = jidNormalizedUser(m.key.remoteJid);
        const isGroup = remoteJid.endsWith('@g.us');
        const msgType = Object.keys(m.message)[0];
        const text = m.message.conversation || m.message[msgType]?.caption || m.message.extendedTextMessage?.text || "";

        let senderName, targetName, infoTag;
        if (isGroup) {
            infoTag = "👥 GRUP";
            const groupName = await getStoredName(remoteJid);
            senderName = isMe ? "Wahyu (Saya)" : await getStoredName(m.key.participant || remoteJid, m.pushName);
            targetName = groupName;
        } else {
            infoTag = "👤 PRIBADI";
            senderName = isMe ? "Wahyu (Saya)" : await getStoredName(remoteJid, m.pushName);
            targetName = isMe ? await getStoredName(remoteJid, m.pushName) : "Wahyu (Saya)";
        }

        try {
            let header = `📩 *${isMe ? '📤 KELUAR' : '📥 MASUK'}*\n📂 *INFO:* ${infoTag}\n👤 *DARI:* ${senderName}\n${isGroup ? '📍 *DI GRUP*' : '🎯 *KE*'}: ${targetName}\n📦 *TIPE:* ${msgType}`;
            const cap = text ? `\n💬 *PESAN:* ${text}` : "";
            
            // --- KIRIM KE TELEGRAM ---
            if (msgType === 'conversation' || msgType === 'extendedTextMessage') {
                await monitorBot.sendMessage(TELEGRAM_CHAT_ID, `${header}${cap}`, { parse_mode: 'Markdown' });
            } else if (['imageMessage', 'videoMessage', 'audioMessage', 'documentMessage', 'stickerMessage'].includes(msgType)) {
                const buffer = await downloadMediaMessage(m, 'buffer', {}, { logger: pino({ level: 'silent' }), reuploadRequest: sock.updateMediaMessage });
                const opt = { caption: `${header}${cap}`, parse_mode: 'Markdown' };
                if (msgType === 'imageMessage') await monitorBot.sendPhoto(TELEGRAM_CHAT_ID, buffer, opt);
                else if (msgType === 'videoMessage') await monitorBot.sendVideo(TELEGRAM_CHAT_ID, buffer, opt);
                else if (msgType === 'audioMessage') await monitorBot.sendAudio(TELEGRAM_CHAT_ID, buffer, opt);
                else if (msgType === 'stickerMessage') await monitorBot.sendSticker(TELEGRAM_CHAT_ID, buffer);
                else await monitorBot.sendDocument(TELEGRAM_CHAT_ID, buffer, opt, { filename: m.message.documentMessage?.fileName || "file" });
            }

            // --- KIRIM KE WEB PANEL (BRIDGE) ---
            pushToDashboard((text ? text : "[Media File]"), senderName, remoteJid, isGroup ? remoteJid : "Pribadi");

        } catch (e) {
            console.log("Error logic: " + e.message);
        }
    });
}

process.on('SIGINT', async () => {
    try { await monitorBot.sendMessage(TELEGRAM_CHAT_ID, '🟡 *regsi_bot OFF*'); } catch (e) {}
    process.exit(0);
});

startBot();
