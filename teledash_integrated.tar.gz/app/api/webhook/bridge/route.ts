import { NextRequest, NextResponse } from 'next/server';
import db from '@/lib/db';
import { eventEmitter } from '@/lib/events';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    
    // Auth Check
    const token = req.headers.get('Authorization');
    const expectedToken = `Bearer ${process.env.TELEGRAM_BOT_TOKEN}`;
    if (token !== expectedToken) {
       return NextResponse.json({ error: 'Unauthorized Bridge Access' }, { status: 401 });
    }

    const { chatId, telegramId, username, firstName, text, messageId } = body;

    // 1. Save Message
    const insertMsg = db.prepare(`
      INSERT INTO Message (messageId, chatId, text, username, firstName)
      VALUES (?, ?, ?, ?, ?)
    `);
    const result = insertMsg.run(messageId || Date.now(), chatId || 'bridge', text || '[Media]', username || 'System', firstName || 'WA-User');
    const savedMessageId = result.lastInsertRowid;

    // 2. Update User Stats (New: Integration for WhatsApp users)
    const waId = telegramId ? (telegramId.includes('@') ? `WA-${telegramId.split('@')[0]}` : telegramId) : `WA-${username || 'Unknown'}`;
    const userExists = db.prepare('SELECT id FROM TelegramUser WHERE telegramId = ?').get(waId);
    
    if (userExists) {
      db.prepare(`
        UPDATE TelegramUser 
        SET username = ?, firstName = ?, lastMessage = ?, 
            messageCount = messageCount + 1, updatedAt = CURRENT_TIMESTAMP
        WHERE telegramId = ?
      `).run(username || firstName, firstName || 'WA-User', text || '[Media]', waId);
    } else {
      db.prepare(`
        INSERT INTO TelegramUser (telegramId, username, firstName, lastMessage, messageCount)
        VALUES (?, ?, ?, ?, 1)
      `).run(waId, username || firstName, firstName || 'WA-User', text || '[Media]');
    }

    // 3. Emit event for SSE Live Stream
    eventEmitter.emit('new-message', {
      type: 'message',
      data: {
        id: savedMessageId,
        chatId: chatId || 'bridge',
        text: text || '[Media]',
        username: username || firstName || 'WA-User',
        createdAt: new Date().toISOString()
      }
    });

    return NextResponse.json({ ok: true, id: savedMessageId });
  } catch (error) {
    console.error('Bridge Error:', error);
    return NextResponse.json({ ok: false, error: 'Internal Server Error' }, { status: 500 });
  }
}
